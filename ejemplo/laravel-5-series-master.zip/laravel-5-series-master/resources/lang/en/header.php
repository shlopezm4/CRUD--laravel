<?php
 
return [
  'posts' => 'Posts',
  'login' => 'Login',
  'register' => 'Register',
  'administration' => 'Administration',
  'notifications' => 'Notifications',
  'hascommented' => '<i>:user</i> has commented in <b>:post</b>',
];