<?php
 
return [
  'posts' => 'Entradas',
  'login' => 'Iniciar sesión',
  'register' => 'Registro',
  'administration' => 'Administración',
  'notifications' => 'Notificaciones',
  'hascommented' => '<i>:user</i> ha comentado en <b>:post</b>',
];