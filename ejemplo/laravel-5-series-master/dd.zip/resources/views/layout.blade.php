<html>
<head>
  <title>Laravel Blog</title>
</head>
<body>
  <header>
    this is a header
  </header>
  <div id="container">
    @yield('content')
  </div>
  <footer>
    this is a footer
  </footer>
</body>
</html>