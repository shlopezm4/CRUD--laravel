<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
      <div class="col-md-8 col-md-offset-2">
        
        <h3><?php echo e($post->title); ?></h3>
        <div>
          <?php echo $post->body; ?>

          <p>By <?php echo e($post->user->name); ?></p>
        </div>
        <h3>Comments</h3>
        <?php if(Auth::check()): ?>
          <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo e(Form::open(['route' => ['comments.store'], 'method' => 'POST'])); ?>

          <p><?php echo e(Form::textarea('body', Input::old('body'))); ?></p>
          <?php echo e(Form::hidden('post_id', $post->id)); ?>

          <p><?php echo e(Form::submit('Send')); ?></p>
        <?php echo e(Form::close()); ?>

        <?php endif; ?>
        <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <p><?php echo e($comment->user->name); ?> <?php echo e($comment->created_at); ?></p>
          <p><?php echo e($comment->body); ?></p>
          <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>This post has no comments</p>
        <?php endif; ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>