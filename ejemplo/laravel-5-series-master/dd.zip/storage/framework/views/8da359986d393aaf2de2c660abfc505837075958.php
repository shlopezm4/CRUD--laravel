<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h3>User list</h3>
            <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Options</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="<?php echo e(($user->active == 0) ? 'danger' : ''); ?>">
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <?php $__currentLoopData = $user->roles()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-default"><?php echo e($role); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php if(Auth::id() != $user->id): ?>
                                <button type="button" class="btn-modal-change-role btn btn-info btn-sm" data-userid="<?php echo e($user->id); ?>" data-userrole="<?php echo e($role); ?>">Change role</button>
                                <?php echo e(Form::open(['route' => ['admin.users.active_deactive'], 'method' => 'POST'])); ?>

                                    <?php echo e(Form::hidden('user_id', $user->id)); ?>

                                    <?php echo e(Form::submit(($user->active == 0) ? 'Reactive' : 'Deactivate', ['name' => 'submit', 'class' => 'btn btn-warning btn-sm'])); ?>

                                <?php echo e(Form::close()); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">No results</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="roleModal" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Change role</h3>
            </div>
            <div class="modal-body">
                <?php echo e(Form::open(['route' => ['admin.users.change_role'], 'method' => 'POST'])); ?>

                    <?php echo e(Form::hidden('user_id')); ?>

                    <p><?php echo e(Form::select('role', $roles, null, ['class' => 'form-control'])); ?></p>
                    <?php echo e(Form::submit('Change', ['name' => 'submit', 'class' => 'btn btn-success btn-block btn-change-role'])); ?>

                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>