<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
      <div class="col-md-6 col-md-offset-1">
        <h3>Posts</h3>

        <?php echo e(Form::open(['route' => ['posts.index'], 'method' => 'GET'])); ?>

          <p><?php echo e(Form::text('search', Input::old('search'), array('placeholder'=>'Search'))); ?></p>
          <p><?php echo e(Form::submit('Search')); ?></p>
        <?php echo e(Form::close()); ?>


        <?php if(Auth::check() && Auth::user()->hasPermissionTo('post_create')): ?>
          <h4>Create post</h4>
          <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('includes.form-submit-post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <h4><?php echo e($post->title); ?></h4>
            <span><?php echo e($post->comments->count()); ?> <?php echo e(str_plural('comment', $post->comments->count())); ?></span>
            <p>By <?php echo e($post->user->name); ?> on <?php echo e($post->created_at); ?></p>
            <a href="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>">Go</a>
            <?php if(Auth::check() && ($post->user_id == Auth::id() || Auth::user()->hasRole('administrator'))): ?>
              <a href="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>/edit">Edit</a>
              <form action="<?php echo e(URL::to('/')); ?>/post/<?php echo e($post->id); ?>" method="POST">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>


                  <button type="submit" onclick="return confirm('Are you sure?')">Delete</button>
              </form>
            <?php endif; ?>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>No posts</p>
        <?php endif; ?>

        <?php if(count($posts)): ?>
          
          <?php echo $__env->make('includes.pagination', ['paginator' => $posts], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

      </div>
      <div class="col-md-2 col-md-offset-1">
        <h3>Active users</h3>
        <?php $__empty_1 = true; $__currentLoopData = $active_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <p><?php echo e($user->name); ?> (<?php echo e($user->last_login->diffForHumans()); ?>)</p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>No users</p>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>