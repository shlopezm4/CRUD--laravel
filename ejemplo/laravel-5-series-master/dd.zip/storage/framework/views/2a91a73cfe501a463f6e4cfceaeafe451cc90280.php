<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">

      <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo e(Form::model($post, ['route' => ['posts.update', $post->id], 'method' => 'PATCH'])); ?>

        <p><?php echo e(Form::text('title', Input::old('title'))); ?></p>
        <p><?php echo e(Form::textarea('body', Input::old('body'), ['class' => 'textarea-wysiwyg'])); ?></p>
        <p><?php echo e(Form::submit('Save', ['name' => 'submit'])); ?></p>
      <?php echo e(Form::close()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>