<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <?php echo $__env->make('includes.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <img width="100px" height="100px" src="<?php echo e(asset('uploads/avatars/'.$user->avatar)); ?>">
        <h2><?php echo e($user->name); ?></h2>
        <h4>Edit avatar</h4>
        <?php echo e(Form::open(['route' => ['user.profile.update'], 'files' => true, 'method' => 'PATCH'])); ?>

          <p><?php echo e(Form::file('avatar')); ?></p>
          <p><?php echo e(Form::submit('Update', ['name' => 'submit'])); ?></p>
        <?php echo e(Form::close()); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>