<form id="save_post" method="post" action="<?php echo e(URL::to('/')); ?>/posts">
  <?php echo e(csrf_field()); ?>

  <div>
    <p>Title</p>
    <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>">
  </div>
  
  <div>
    <p>Body</p>
    <textarea class="textarea-wysiwyg" id="body" name="body"><?php echo e(old('body')); ?></textarea>
  </div>
  
  <div>
    <input type="submit" value="Save">
  </div>
</form>